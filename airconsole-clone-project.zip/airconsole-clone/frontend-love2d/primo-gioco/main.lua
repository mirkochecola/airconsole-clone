function love.load()
  love.graphics.setFont(love.graphics.newFont(20))
  inputRicevuto = "Nessun input"
end

function love.draw()
  love.graphics.print("Input controller: "..inputRicevuto, 50, 50)
end

function love.update(dt)
  local file = io.open("input.txt", "r")
  if file then
    inputRicevuto = file:read("*all")
    file:close()
  end
end